# Car Dealership Sales Analysis
This is aimed to design and develop a comprehensive and interactive Car Sales Dashboard using Power BI with the help of DAX functions and SQL. The dashboard visualizes critical KPIs related to car sales of the dealership.

![Car Sales Dashboard](https://github.com/Ilma0102/Power-BI-projects/assets/165472394/b12e892d-433b-4021-b734-0dcdbda63e98)
